<?php

include_once dirname(__FILE__) . '/' . 'page.php';
include_once dirname(__FILE__) . '/' . 'detail_page.php';
include_once dirname(__FILE__) . '/' . 'nested_form_page.php';
include_once dirname(__FILE__) . '/' . 'view_based_page.php';
